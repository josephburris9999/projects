<%-- 
	Common link to external javascript files and inline javascript functions for the jsp's.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>


<script type="text/javascript" src="<%=request.getContextPath()%>/js/jquery.min.js"></script>
<script type="text/javascript" src="<%=request.getContextPath()%>/js/popper.min.js"></script>
<script type="text/javascript" src="<%=request.getContextPath()%>/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
	$('#cancelModal').on('shown.bs.modal', function() {
		let modal = $(this);
		modal.find('#continue').focus();
	});
</script>