<%-- 
	Common page header for the jsp's.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
	import="com.wallflowertech.cupids.models.Customer,com.wallflowertech.cupids.models.IConstants" %>
<%
	Customer customer = (Customer) request.getSession().getAttribute(IConstants.CUSTOMER_SESSION_KEY);
%>
<header>
	<nav class="navbar fixed-top">
		<div class="container">
			<%
				if (null != customer) {
			%>
				<a class="link-primary" href="#" data-bs-toggle="modal" data-bs-target="#cancelModal">
					<img src="<%=request.getContextPath()%>/images/cupids.svg" width="30" alt="heart outline pierced through with an arrow"> Cupid&#39;s
				</a>
			<%
				} else {
			%>
				<a class="link-primary" href="<%=request.getContextPath()%>">
					<img src="<%=request.getContextPath()%>/images/cupids.svg" width="30" alt="heart outline pierced through with an arrow"> Cupid&#39;s
				</a>
			<%
				}
			%>
			<%
				if (null != customer) {
			%>
				<div class="float-end">
					<a class="link-primary" href="#" data-bs-toggle="modal" data-bs-target="#cancelModal">
						Cancel Order
					</a>
				</div>
			<%
				}
			%>
		</div>
	</nav>
	<div id="cancelModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Cancel Order</h4>
				</div>
				<div class="modal-body">
					<p>
						Are you sure you want to abandon your order?
					</p>
				</div>
				<div class="modal-footer">
					<button type="button" id="continue" value="previous" data-bs-dismiss="modal">Continue</button>
					<button type="submit" id="cancel" value="next" data-bs-dismiss="modal" onclick="location.href='<%=request.getContextPath()%>/cancel';">Cancel Order</button>
				</div>
			</div>
		</div>
	</div>
</header>