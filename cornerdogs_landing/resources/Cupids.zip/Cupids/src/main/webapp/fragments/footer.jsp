<%-- 
	Common page footer for the jsp's.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<footer class="footer w-100 p-3 text-center">
	<small class="fs-7">
		Copyright &copy; 2024 <a class="link-primary" href="http://localhost:9090/">Wallflower Tech, L.L.C.</a>, all rights reserved.
	</small>
</footer>
