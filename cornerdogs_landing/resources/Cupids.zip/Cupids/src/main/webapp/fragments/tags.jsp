<%-- 
	Common links to  header tags for the jsp's.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Wizard demonstration application.">
<meta name="author" content="joseph.burris@gmail.com (place-holder)">
<link rel="icon" type="image/svg" href="<%=request.getContextPath()%>/images/cupids.svg">
<link rel="stylesheet" type="text/css" href="<%=request.getContextPath()%>/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<%=request.getContextPath()%>/css/bootstrap-icons.css">
<link rel="stylesheet" type="text/css" href="<%=request.getContextPath()%>/css/site.css">
<link rel="stylesheet" type="text/css" href="<%=request.getContextPath()%>/css/wallflowertech-theme.css">
<link rel="stylesheet" type="text/css" href="<%=request.getContextPath()%>/css/wallflowertech-link-button.css">
