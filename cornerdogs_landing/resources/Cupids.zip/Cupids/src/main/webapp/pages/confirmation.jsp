<%-- 
	Submit confirmation page.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html>
	<head>
		<jsp:include page="/fragments/tags.jsp"/>
		<title>Cupid&#39;s &#8212; Order Confirmation</title>
	</head>
	<body>
		<jsp:include page="/fragments/header.jsp"/>
		<main>
			<section class="jumbotron w-100">
				<h1 class="py-5 text-center">Thank you for your business at Cupid&#39;s!</h1>
			</section>
			<section class="container mt-5">
				<div class="row pt-5 my-3">
					<div class="col-md-12">
						<h2 class="text-center">Your order has been submitted!</h2>
					</div>
				</div>
				<div class="row mb-2">
					<div class="col-md-12">
						Don&#39;t go anywhere! Your order will be ready for pick-up
						in just a moment!
					</div>
				</div>
				<div class="row mb-2">
					<div class="col-md-12">
						<button class="btn btn-md btn-primary float-end" type="button" name="submit" value="next" onclick="location.href='<%=request.getContextPath()%>/index.jsp'">Do it again!</button>
					</div>
				</div>
			</section>
		</main>
		<jsp:include page="/fragments/footer.jsp"/>
		<jsp:include page="/fragments/scripts.jsp"/>
	</body>
</html>