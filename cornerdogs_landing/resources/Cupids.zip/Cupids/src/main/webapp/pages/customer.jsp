<%-- 
	Customer page.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
	import="com.wallflowertech.cupids.models.Customer,com.wallflowertech.cupids.models.IConstants" %>
<%@ taglib uri="/WEB-INF/tlds/custom-tags.tld" prefix="render" %>
<%
	Customer model = ((Customer) request.getSession().getAttribute(IConstants.CUSTOMER_SESSION_KEY));
%>

<!DOCTYPE html>
<html lang="en-US">
	<head>
		<jsp:include page="/fragments/tags.jsp"/>
		<title>Cupid&#39;s &#8212; Customer Page</title>
	</head>
	<body>
		<jsp:include page="/fragments/header.jsp"/>
		<jsp:include page="/fragments/breadcrumb.jsp"/>
		<main>
			<form method="post" action="<%=request.getContextPath()%>/customer">
				<section class="container mt-5">
					<div class="row pt-5 my-3">
						<div class="col-md-12 text-center">
							<h2>Customer</h2>
							<p class="text-muted">Items marked with an asterisk ( * ) are required.</p>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-4 form-group">
							<render:text type="text" id="name" name="name" label="Name*" value='<%=model.getName()%>' error='<%=model.getError("nameError")%>' />
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-12">
							<button class="btn btn-md btn-primary float-start" type="submit" name="submit" value="previous">Welcome!</button>
							<button class="btn btn-md btn-primary float-end" type="submit" name="submit" value="next">Order Page</button>
						</div>
					</div>
				</section>
			</form>
		</main>
		<jsp:include page="/fragments/footer.jsp"/>
		<jsp:include page="/fragments/scripts.jsp"/>
		<script>
			jQuery(document).ready(
				function($) {
					$('input[name=name]').attr('maxlength', '25');
					$('input[name=name]').focus();
				});
		</script>
	</body>
</html>
