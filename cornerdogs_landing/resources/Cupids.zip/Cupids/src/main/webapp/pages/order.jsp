<%-- 
	Order page.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
	import="com.wallflowertech.cupids.models.Customer,com.wallflowertech.cupids.models.IConstants,com.wallflowertech.cupids.models.Order"%>
<%@ taglib uri="/WEB-INF/tlds/custom-tags.tld" prefix="render" %>
<%
	Customer customer = ((Customer)request.getSession().getAttribute(IConstants.CUSTOMER_SESSION_KEY));
	Order model = customer.getOrder();
%>

<!DOCTYPE html>
<html lang="en-US">
	<head>
		<jsp:include page="/fragments/tags.jsp"/>
		<title>Cupid&#39;s &#8212; Order Page</title>
	</head>
	<body>
		<jsp:include page="/fragments/header.jsp"/>
		<jsp:include page="/fragments/breadcrumb.jsp"/>
		<main>
			<form method="post" action="<%=request.getContextPath()%>/order">
				<section class="container mt-5">
					<div class="row pt-5 my-3">
						<div class="col-md-12 text-center">
							<h2>Order</h2>
							<p class="text-muted">Items marked with an asterisk ( * ) are required.</p>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-4">
							<render:select id="where" name="where" label="Where will you take your order?*" value='<%=model.getWhere().getKey()%>' qualifiedPath="com.wallflowertech.cupids.enums.Where" error='<%=model.getError("whereError")%>'/>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-12">
							<p>
								How many hot dogs would you like?*
								<span class="error"><%=model.getError("orderError")%></span>
							</p>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-12 form-group">
							<render:text type="number" id="hotDogs" name="hotDogs" label="Hot Dogs" value='<%=model.getHotDogs()%>' error='<%=model.getError("hotDogError")%>' />
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-12 form-group">
							<render:text type="number" id="withEverything" name="withEverything" label="Hot Dogs with Everything" value='<%=model.getWithEverything()%>' error='<%=model.getError("withEverythingError")%>' />
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-12">
							<button class="btn btn-md btn-primary float-start" type="submit" name="submit" value="previous">Customer Page</button>
							<button class="btn btn-md btn-primary float-end" type="submit" name="submit" value="next">Verification</button>
						</div>
					</div>
				</section>
			</form>
		</main>
		<jsp:include page="/fragments/footer.jsp"/>
		<jsp:include page="/fragments/scripts.jsp"/>
		<script>
			jQuery(document).ready(
				function($) {
					$('input[name=hotDogs]').attr('min', '0');
					$('input[name=hotDogs]').attr('max', '99');
					$('input[name=hotDogs]').attr('style', 'width:100px;');
					$('input[name=withEverything]').attr('min', '0');
					$('input[name=withEverything]').attr('max', '99');
					$('input[name=withEverything]').attr('style', 'width:100px;');
					$('select[name=where]').focus();
				});
		</script>
	</body>
</html>