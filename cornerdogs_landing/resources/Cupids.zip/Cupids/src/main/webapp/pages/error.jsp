<%-- 
	Error page.
	@author joseph.burris@gmail.com (place-holder)
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="en-US">
	<head>
		<jsp:include page="/fragments/tags.jsp"/>
		<title>Cupid&#39;s &#8212; Error</title>
	</head>
	<body>
		<jsp:include page="/fragments/header.jsp"/>
		<main>
			<section class="jumbotron w-100">
				<h1 class="py-5 text-center">Cupid&#39;s Hot Dogs</h1>
			</section>
			<section class="container mt-5">
				<div class="row pt-5 my-3">
					<div class="col-md-12">
						<h2 class="text-center text-danger">You have encountered an error!</h2>
					</div>
				</div>
				<div class="row mb-2">
					<div class="col-md-12">
						<p>
							Please contact the administrator and inform them of this error and how you got here.
						</p>
						<p>
							You may try using the back button to go back and attempt your action again.
						</p>
					</div>
				</div>
				<div class="row mb-2">
					<div class="col-md-12">
						<button class="btn btn-md btn-primary float-end" type="button" value="previous" onclick="window.history.back();">Back</button>
					</div>
				</div>
			</section>
		</main>
		<jsp:include page="/fragments/footer.jsp"/>
		<jsp:include page="/fragments/scripts.jsp"/>
	</body>
</html>