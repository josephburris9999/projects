/**
 * @(#)Where.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.enums;

import com.wallflowertech.wizard.tags.Common;

/**
 * This {@code enum} is used to store labels for reference.
 * 
 * @author joseph.burris@gmail.com (place-holder)
 * @see com.wallflowertech.wizard.tags.Common
 */
public enum Where implements Common {
	EMPTY("", "..."), //
	HERE("HERE", "For Here"), //
	TOGO("TOGO", "To Go");

	private final String key;
	private final String value;

	/**
	 * {@code private} overloaded constructor instantiates this class
	 * 
	 * @param key   the {@code enum} key
	 * @param value the {@code enum} value
	 */
	private Where(String key, String value) {
		this.key = key;
		this.value = value;
	}// end constructor

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.wizard.tags.Common#getKey()
	 */
	@Override
	public String getKey() {
		return key;
	}// end getKey

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.wizard.tags.Common#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}// end getValue
}// end enum
