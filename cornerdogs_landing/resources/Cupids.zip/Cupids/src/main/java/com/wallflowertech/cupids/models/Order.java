/**
 * @(#)Order.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.models;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import com.wallflowertech.cupids.enums.Where;

/**
 * This class models the customer order from the order JSP.
 * 
 * @author joseph.burris@gmail.com
 * @see com.wallflowertech.cupids.models.AbstractModel
 */
public class Order extends AbstractModel {
	private static final long serialVersionUID = 1L;
	private Timestamp when;
	private Where where;
	private int hotDogs;
	private int withEverything;

	/**
	 * default constructor instantiates this class
	 */
	public Order() {
		super();
		this.when = new Timestamp(System.currentTimeMillis());
	}// end constructor

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.models.AbstractModel#setValues(Map<String, String[])
	 */
	@Override
	public void setValues(Map<String, String[]> map) {
		setSubmit(map.get("submit")[0]);
		setWhere(map.get("where")[0]);
		setHotDogs(map.get("hotDogs")[0]);
		setWithEverything(map.get("withEverything")[0]);
		if (0 == getHotDogs() && 0 == getWithEverything()) {
			super.getErrors().put("orderError", "Must have at least one hot dog in your order.");
		} // end if
	}// end setValues

	/**
	 * returns the formatted order timestamp
	 * 
	 * @return the order timestamp in M/d/yy H:m a format
	 */
	public String getFormattedWhen() {
		return new SimpleDateFormat(SDF_TIMESTAMP).format(when);
	}// end getFormattedWhen

	/**
	 * returns the total number of hot dogs ordered
	 * 
	 * @return the sum of hot dogs and hot dogs with everything ordered
	 */
	public int getHotDogCount() {
		return getHotDogs() + getWithEverything();
	}

	/**
	 * returns the price of the ordered hot dogs
	 * 
	 * @return the ordered hot dogs price in currency format
	 */
	public String getHotDogsPrice() {
		return getPrice(getHotDogs());
	}// end getHotDogsPrice

	/**
	 * returns the price of the order hot dogs with everything
	 * 
	 * @return the ordered hot dogs with everything price in currency format
	 */
	public String getWithEverythingPrice() {
		return getPrice(getWithEverything());
	}// end getWithEverythingPrice

	/**
	 * returns the sub-total for both the ordered hot dogs and hot dogs with everything
	 * 
	 * @return the ordered hot dogs and hot dogs with everything sub-total in currency format
	 */
	public String getSubTotal() {
		return getPrice(getHotDogCount());
	}// end getSubTotal

	/**
	 * returns the price of the hot dog multiplied by the number of hot dogs ordered
	 * 
	 * @param n the number of hot dogs ordered
	 * @return the number of ordered hot dogs price in currency format
	 */
	public String getPrice(int n) {
		StringBuffer buffer = new StringBuffer();
		if (0 != n) {
			BigDecimal price = getMultiplied(n, InitParameters.HOT_DOG_PRICE);
			buffer.append(getFormatted(price));
		} // end if
		return buffer.toString();
	}// end getPrice

	/**
	 * returns the tax for both the ordered hot dogs and hot dogs with everything
	 * 
	 * @return the ordered hot dogs and hot dogs with everything tax in currency format
	 */
	public String getTax() {
		StringBuffer buffer = new StringBuffer();
		int n = getHotDogCount();
		if (0 != n) {
			BigDecimal tax = getMultiplied(n, InitParameters.TAX_RATE);
			buffer.append(getFormatted(tax));
		} // end if
		return buffer.toString();
	}// end getTax

	/**
	 * returns the total for both the ordered hot dogs and hot dogs with everything plus tax
	 * 
	 * @return the ordered hot dogs and hot dogs with everything total plus tax in currency format
	 */
	public String getTotal() {
		StringBuffer buffer = new StringBuffer();
		int n = getHotDogCount();
		if (0 != n) {
			BigDecimal price = getMultiplied(n, InitParameters.HOT_DOG_PRICE);
			BigDecimal tax = getMultiplied(n, InitParameters.TAX_RATE);
			BigDecimal total = price.add(tax);
			buffer.append(getFormatted(total));
		} // end if
		return buffer.toString();
	}// end getTotal

	/**
	 * multiplies a currency amount by the ordered quantity
	 * 
	 * @param n     the ordered quantity
	 * @param param the currency amount
	 * @return a {@link java.math.BigDecimal} result of the multiplication
	 */
	private BigDecimal getMultiplied(int n, String param) {
		if (0 != n) {
			BigDecimal price = new BigDecimal(param);
			return price.multiply(new BigDecimal(n));
		} // end if
		return new BigDecimal(0);
	}// end getMultiplied

	/**
	 * formats the parameter in currency format
	 * 
	 * @param decimal the parameter to format
	 * @return the currency formatted value of the parameter
	 */
	private String getFormatted(BigDecimal decimal) {
		NumberFormat format = NumberFormat.getCurrencyInstance();
		format.setMinimumFractionDigits(2);
		return format.format(decimal.doubleValue());
	}// end getFormatted

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Order [when=" + when + ", where=" + where + ", hotDogs=" + hotDogs + ", withEverything=" + withEverything + ", getUid()=" + getUid() + ", getErrors()=" + getErrors() + ", getSubmit()=" + getSubmit() + ", toString()=" + super.toString() + "]";
	}// end toString

	/**
	 * returns the order timestamp
	 * 
	 * @return the timestamp of the order
	 */
	public Timestamp getWhen() {
		return when;
	}// end getWhen

	/**
	 * sets the order timestamp
	 * 
	 * @param when the timestamp to set
	 */
	public void setWhen(String when) {
		if (validateDate("whenError", when, "When", "future")) {
			this.when = parseTimestamp(when);
		} // end if
	}// end setWhen

	/**
	 * sets the order timestamp
	 * 
	 * @param when the timestamp to set
	 */
	public void setWhen(Timestamp when) {
		this.when = when;
	}// end setWhen

	/**
	 * returns the where to receive the order
	 * 
	 * @return where to receive the order
	 */
	public Where getWhere() {
		return null != where ? where : Where.EMPTY;
	}// end getWhere

	/**
	 * sets where to receive the order
	 * 
	 * @param where where to receive the order
	 */
	public void setWhere(String where) {
		if (validateString("whereError", where, "For here or to go", 4)) {
			this.where = !"".equals(where) ? Where.valueOf(where) : Where.EMPTY;
		} // end if
	}// end setWhere

	/**
	 * returns the number of hot dogs ordered
	 * 
	 * @return the quantity of hot dogs for the order
	 */
	public int getHotDogs() {
		return hotDogs;
	}// end getHotDogs

	/**
	 * set the number of hot dogs ordered
	 * 
	 * @param hotDogs the quantity of hot dogs ordered
	 */
	public void setHotDogs(String hotDogs) {
		if (validateNumber("hotDogsError", hotDogs, "hot dogs", 2)) {
			this.hotDogs = Integer.parseInt(hotDogs);
		} // end if
	}// end setHotDogs

	/**
	 * set the number of hot dogs ordered
	 * 
	 * @param hotDogs the quantity of hot dogs ordered
	 */
	public void setHotDogs(int hotDogs) {
		this.hotDogs = hotDogs;
	}// end setHotDogs

	/**
	 * returns the number of hot dogs with everything ordered
	 * 
	 * @return the quantity of hot dogs with everything for the order
	 */
	public int getWithEverything() {
		return withEverything;
	}// end getWithEverything

	/**
	 * set the number of hot dogs with everything ordered
	 * 
	 * @param hotDogs the quantity of hot dogs with everything ordered
	 */
	public void setWithEverything(String withEverything) {
		if (validateNumber("withEverythingError", withEverything, "hot dogs with everything", 2)) {
			this.withEverything = Integer.parseInt(withEverything);
		} // end if
	}// end setWithEverything

	/**
	 * set the number of hot dogs with everything ordered
	 * 
	 * @param hotDogs the quantity of hot dogs with everything ordered
	 */
	public void setWithEverything(int withEverything) {
		this.withEverything = withEverything;
	}// end setWithEverything
}// end class
