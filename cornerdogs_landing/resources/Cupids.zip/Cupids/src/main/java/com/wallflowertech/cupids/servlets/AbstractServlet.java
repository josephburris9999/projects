/**
 * @(#)AbstractServlet.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.wallflowertech.cupids.controllers.Processor;
import com.wallflowertech.cupids.models.AbstractModel;
import com.wallflowertech.cupids.models.Breadcrumb;
import com.wallflowertech.cupids.models.Customer;
import com.wallflowertech.cupids.models.IConstants;

/**
 * Super-class for servlets in the application.
 * 
 * @author joseph.burris@gmail.com (place-holder)
 * @see javax.servlet.http.HttpServlet
 */
public abstract class AbstractServlet extends HttpServlet implements IConstants {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger("com.wallflowertech.cupids.servlets.AbstractServlet");

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Breadcrumb breadcrumb = getBreadcrumb(request);
		breadcrumb.put(getCurrentPath(), getCurrentTitle());
		request.getSession().setAttribute(BREADCRUMB_SESSION_KEY, breadcrumb);
		Customer customer = getCustomer(request);
		request.getSession().setAttribute(CUSTOMER_SESSION_KEY, customer);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(getCurrentPath());
		dispatcher.forward(request, response);
	}// end doGet

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Breadcrumb breadcrumb = getBreadcrumb(request);
		breadcrumb.put(getCurrentPath(), getCurrentTitle());
		Customer customer = getCustomer(request);
		AbstractModel object = customer.getObject(getObjectName());
		object.clearErrors();
		object.setValues(request.getParameterMap());
		RequestDispatcher dispatcher;
		if (null != object.getSubmit()) {
			if ("previous".equalsIgnoreCase(object.getSubmit())) {
				dispatcher = getServletContext().getRequestDispatcher(getPreviousPath());
			} else if ("next".equalsIgnoreCase(object.getSubmit())) {
				if (object.getErrors().isEmpty()) {
					if (isLastPage()) {
						new Processor().save(customer);
						request.getSession().invalidate();
					}// end if
					breadcrumb.put(getNextPath(), getNextTitle());
					dispatcher = getServletContext().getRequestDispatcher(getNextPath());
				} else {
					dispatcher = getServletContext().getRequestDispatcher(getCurrentPath());
					request.getSession().setAttribute(CUSTOMER_SESSION_KEY, customer);
				}// end if/else
			} else {
				throw new RuntimeException("Unknown submit selected for path: " + request.getRequestURI());
			}// end if/else
		} else {
			throw new RuntimeException("Unknown submit selected for path: " + request.getRequestURI());
		}// end if/else
		dispatcher.forward(request, response);
	}// end doPost

	/**
	 * returns the customer from the session
	 * 
	 * @param request the client request
	 * @return the {@link com.wallflowertech.cupids.models.Customer} in session
	 */
	protected Customer getCustomer(HttpServletRequest request) {
		Customer customer = (Customer) request.getSession().getAttribute(CUSTOMER_SESSION_KEY);
		if (null == customer) {
			logger.debug("The customer does not exist in session. Setting it now.");
			customer = new Customer();
		}// end if
		return customer;
	}// end getCustomer

	/**
	 * returns the breadcrumb from the session
	 * 
	 * @param request the client request
	 * @return the {@link com.wallflowertech.cupids.models.Breadcrumb} in session
	 */
	protected Breadcrumb getBreadcrumb(HttpServletRequest request) {
		Breadcrumb breadcrumb = (Breadcrumb) request.getSession().getAttribute(BREADCRUMB_SESSION_KEY);
		if (null == breadcrumb) {
			breadcrumb = new Breadcrumb();
			breadcrumb.put("/index.jsp", "Welcome");
		}// end if
		return breadcrumb;
	}// end getBreadcrumb

	/**
	 * returns the name of the sub-class
	 * 
	 * @return the name of the sub-class backing the JSP
	 */
	protected abstract String getObjectName();

	/**
	 * returns the title of the page last displayed
	 * 
	 * @return the title for the page previously rendered by the servlet
	 */
	protected abstract String getPreviousTitle();

	/**
	 * returns the path of the page last displayed
	 * 
	 * @return the context path of the servlet previously rendered
	 */
	protected abstract String getPreviousPath();

	/**
	 * returns the title of the current page
	 * 
	 * @return the title for the page being rendered by the servlet
	 */
	protected abstract String getCurrentTitle();

	/**
	 * returns the path of the current page
	 * 
	 * @return the context path of the JSP being rendered by the servlet.
	 */
	protected abstract String getCurrentPath();

	/**
	 * returns the title of the page to display next
	 * 
	 * @return the title for the next page to be rendered by the servlet
	 */
	protected abstract String getNextTitle();

	/**
	 * returns the path of the page to display next
	 * 
	 * @return the context path of the next servlet to render
	 */
	protected abstract String getNextPath();

	/**
	 * returns whether this is the last page for the wizard
	 * 
	 * @return {@code true} if the current servlet sub-class marks the last available page.
	 */
	protected boolean isLastPage() {
		return false;
	}// end isLastPage
}// end class
