/**
 * @(#)Customer.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.models;

import java.util.Map;

/**
 * This class models a customer visit spanning multiple JSP's.
 * 
 * @author joseph.burris@gmail.com
 * @see com.wallflowertech.cupids.models.AbstractModel
 */
public class Customer extends AbstractModel {
	private static final long serialVersionUID = 1L;
	private String name;
	private Order order;
	private Verification verification;

	/**
	 * default constructor instantiates this class
	 */
	public Customer() {
		super();
		this.order = new Order();
		this.verification = new Verification();
	}// end constructor

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.models.AbstractModel#setValues(java.util.Map)
	 */
	@Override
	public void setValues(Map<String, String[]> map) {
		setSubmit(map.get("submit")[0]);
		setName(map.get("name")[0]);

	}// end setValues

	/**
	 * returns the sub-class of {@link com.wallflowertech.cupids.models.AbstractModel} for the canonical
	 * name
	 * 
	 * @param name the name to test against
	 * @return the class variable with the name matching the parameter
	 */
	public AbstractModel getObject(String name) {
		if (Order.class.getCanonicalName().equals(name)) {
			return getOrder();
		} else if (Verification.class.getCanonicalName().equals(name)) {
			return getVerification();
		} else {
			return this;
		} // end if/else
	}// end getObject

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Customer [name=" + name + ", order=" + order + ", verification=" + verification + ", getUid()="
				+ getUid() + ", getErrors()=" + getErrors() + ", getSubmit()=" + getSubmit() + ", toString()="
				+ super.toString() + "]";
	}// end toString

	/**
	 * returns the customer name
	 * 
	 * @return the name of the customer
	 */
	public String getName() {
		return null != name ? name.trim() : "";

	}// end getName

	/**
	 * sets the customer name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
		if (validateString("nameError", name, "Name", 25)) {
			this.name = name;
		} // end if
	}// end setName

	/**
	 * returns the customer order
	 * 
	 * @return the customer {@link com.wallflowertech.cupids.models.Order}
	 */
	public Order getOrder() {
		return order;
	}// end getOrder

	/**
	 * sets the customer order
	 * 
	 * @param order the {@link com.wallflowertech.cupids.models.Order} to set
	 */
	public void setOrder(Order order) {
		this.order = order;
	}// end setOrder

	/**
	 * returns the customer verification
	 * 
	 * @return the customer {@link com.wallflowertech.cupids.models.Verification}
	 */
	public Verification getVerification() {
		return verification;
	}// end getVerification

	/**
	 * sets the customer verification
	 * 
	 * @param verification the {@link com.wallflowertech.cupids.models.Verification} to set
	 */
	public void setVerification(Verification verification) {
		this.verification = verification;
	}// end setVerification
}// end class
