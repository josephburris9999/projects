/**
 * @(#)IConstants.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.models;

import java.util.regex.Pattern;

/**
 * This {@code interface} contains constants for the application.
 * 
 * @author joseph.burris@gmail.com (place-holder)
 */
public interface IConstants {
	/** {@code java.sql.Date} pattern */
	public static final Pattern SQL_DATE_PATTERN = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
	/** {@code java.util.Date} pattern */
	public static final Pattern UTIL_DATE_PATTERN = Pattern.compile("\\d{2}/\\d{2}/\\d{4}");
	/** number pattern */
	public static final Pattern NUMBER_PATTERN = Pattern.compile("\\d{1,7}");

	/** {@code java.text.SimpleDateFormat} for {@code java.sql.Date}s */
	public static final String SDF_SQL_DATE = "yyyy-MM-dd";
	/** {@code java.text.SimpleDateFormat} for {@code java.util.Date}s */
	public static final String SDF_UTIL_DATE = "MM/dd/yyyy";
	/** {@code java.text.SimpleDateFormat} for {@code java.sql.Timestamp}s */
	public static final String SDF_TIMESTAMP = "M/d/yy H:m a";

	/** the operating system specific new line character */
	public static final String NEW_LINE = System.getProperty("line.separator");

	/** the customer session key constant */
	public static final String CUSTOMER_SESSION_KEY = "s_customer";
	/** the breadcrumb session key constant */
	public static final String BREADCRUMB_SESSION_KEY = "s_breadcrumb";

	/**
	 * This class contains pseudo-constants holding values set by initialization parameters in the
	 * deployment descriptor.
	 * 
	 * @author joseph.burris@gmail.com (place-holder)
	 */
	static class InitParameters {
		/** the file path for the log directory */
		public static String LOG_DIRECTORY;
		/** the hot dog price */
		public static String HOT_DOG_PRICE;
		/** the tax rate */
		public static String TAX_RATE;

		/**
		 * builds a {@code String} with the values of the initialization parameters found in the deployment
		 * descriptor
		 * 
		 * @return a {@code String} of initialization parameters
		 */
		public static String print() {
			return new StringBuilder("LOG_DIRECTORY=").append(LOG_DIRECTORY).append(NEW_LINE) //
					.append("HOT_DOG_PRICE=").append(HOT_DOG_PRICE).append(NEW_LINE) //
					.append("TAX_RATE=").append(TAX_RATE).toString();
		}// end print
	}// end nested class
}// end class
