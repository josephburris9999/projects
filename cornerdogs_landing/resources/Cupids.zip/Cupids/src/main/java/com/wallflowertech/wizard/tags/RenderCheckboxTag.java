/**
 * @(#)RenderCheckboxTag.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.wizard.tags;

import javax.servlet.jsp.JspException;

import org.apache.log4j.Logger;

/**
 * This class models a custom checkbox input tag. The code as it lives in a JSP feels bloated;
 * nesting it in a tag where the logic can be repeated without being repeated as a scriptlet reduces
 * the footprint.
 * 
 * @author joseph.burris@gmail.com (place-holder)
 * @see com.wallflowertech.wizard.tags.AbstractTag
 */
public class RenderCheckboxTag extends AbstractTag {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger("com.wallflowertech.wizard.tags.RenderCheckboxTag");

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.jsp.tagext.TagSupport#doStartTag()
	 */
	public int doStartTag() throws JspException {
		StringBuffer buffer = new StringBuffer();
		buffer.append("<div>");
		buffer.append("<label class=\"checkbox-inline\">");
		buffer.append("<input type=\"checkbox\" id=\"").append(id).append("\" name=\"").append(name)
				.append("\" value=\"Y\"");
		if ("Y".equalsIgnoreCase(value)) {
			buffer.append(" checked");
		} // end if
		buffer.append("><span style=\"padding-left:1rem\">").append(label).append("</span>");
		buffer.append("</label>");
		if (null != error) {
			buffer.append("<span class=\"error\">").append(error).append("</span>");
		} // end if
		buffer.append("</div>");
		try {
			pageContext.getOut().print(buffer.toString());
			pageContext.getOut().flush();
		} catch (Exception e) {
			logger.error("Unable to access the JspWriter to render checkbox tag. Message is: " + e.getMessage(), e);
		} // end try/catch
		return EVAL_PAGE;
	}// end doStartTag
}// end class
