/**
 * @(#)AbstractTag.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.wizard.tags;

import javax.servlet.jsp.tagext.TagSupport;

/**
 * This class models the common attributes for the wizard tags.
 * 
 * @author joseph.burris@gmail.com (place-holder)
 * @see javax.servlet.jsp.tagext.TagSupport
 */
public class AbstractTag extends TagSupport {
	private static final long serialVersionUID = 1L;
	protected String label;
	protected String name;
	protected String value;
	protected String error;

	/**
	 * default constructor instantiates this class
	 */
	public AbstractTag() {
		super();
	}// end constructor

	/**
	 * sets the label
	 * 
	 * @param label the label to setff
	 */
	public void setLabel(String label) {
		this.label = label;
	}// end setLabel

	/**
	 * sets the name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}// end setName

	/**
	 * sets the value
	 * 
	 * @param value the value to set
	 */
	public void setValue(Object value) {
		if (null == value) {
			value = "";
		}// end if
		this.value = String.valueOf(value);
	}// end setValue

	/**
	 * sets the error
	 * 
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}// end setError
}// end class
