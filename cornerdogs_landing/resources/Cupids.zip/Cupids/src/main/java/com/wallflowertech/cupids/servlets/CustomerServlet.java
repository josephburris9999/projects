/**
 * @(#)CustomerServlet.java 1.0.0 Copyright (c) 2024 Wallflower Tech, L.L.C., All Rights Reserved.
 *                            <p>
 *                                Redistribution and use in source and binary forms, with or without modification,
 *                                are permitted provided that the following conditions are met:
 *                            </p>
 *                            <ul> 
 *                                <li>
 *                                    Redistribution of source code must retain the above copyright notice,
 *                                    this list of conditions and the following disclaimer.
 *                                </li>
 *                                <li>
 *                                    Redistribution in binary form must reproduce the above copyright notice,
 *                                    this list of conditions and the following disclaimer in the documentation
 *                                    and/or other materials provided with the distribution.
 *                                </li>
 *                                <li>
 *                                    Neither the name of Wallflower Tech, L.L.C., nor the names of contributors
 *                                    may be used to endorse or promote products derived from this software
 *                                    without specific prior written permission.
 *                                </li>
 *                            </ul>
 *                            <p>
 *                                <b>Disclaimer:</b> This software is provided "AS IS," without a warranty of
 *                                any kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 *                                INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *                                PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. WALLFLOWER TECH, L.L.C.,
 *                                AND ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS
 *                                A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *                                IN NO EVENT WILL WALLFLOWER TECH, L.L.C., OR ITS LICENSORS BE LIABLE FOR ANY
 *                                LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 *                                INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 *                                LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN
 *                                IF WALLFLOWER TECH, L.L.C., HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 *                                DAMAGES. You acknowledge that this software is not designed, licensed or
 *                                intended for use in the design, construction, operation or maintenance of any
 *                                nuclear facility.
 *                            </p>
 */
package com.wallflowertech.cupids.servlets;

import javax.servlet.annotation.WebServlet;

import com.wallflowertech.cupids.models.Customer;

/**
 * Servlet implementation class CustomerServlet
 * 
 * @author joseph.burris@gmail.com (place-holder)
 * @see com.wallflowertech.cupids.servlets.AbstractServlet
 */
@WebServlet( //
		description = "processes a customer form", //
		urlPatterns = { //
				"/customer" //
		})
public class CustomerServlet extends AbstractServlet {
	private static final long serialVersionUID = 1L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getObjectName()
	 */
	@Override
	protected String getObjectName() {
		return Customer.class.getCanonicalName();
	}// end getObjectName

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getPreviousTitle()
	 */
	@Override
	protected String getPreviousTitle() {
		return "Welcome";
	}// end getPreviousTitle

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getPreviousPath()
	 */
	@Override
	protected String getPreviousPath() {
		return "/index.jsp";
	}// end getPreviousPath

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getCurrentTitle()
	 */
	@Override
	protected String getCurrentTitle() {
		return "Customer Page";
	}// end getCurrentTitle

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getCurrentPath()
	 */
	@Override
	protected String getCurrentPath() {
		return "/pages/customer.jsp";
	}// end getCurrentPath

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getNextTitle()
	 */
	@Override
	protected String getNextTitle() {
		return "Order Page";
	}// end getNextTitle

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wallflowertech.cupids.servlets.AbstractServlet#getNextPath()
	 */
	@Override
	protected String getNextPath() {
		return "/pages/order.jsp";
	}// end getNextPath
}// end class
